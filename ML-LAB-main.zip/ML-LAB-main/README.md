# 🤖 ML-LAB: Machine Learning Laboratory

[![Python](https://img.shields.io/badge/Python-3.8%2B-blue.svg)](https://www.python.org/)
[![Jupyter](https://img.shields.io/badge/Jupyter-Lab-orange.svg)](https://jupyter.org/)
[![scikit-learn](https://img.shields.io/badge/scikit--learn-Latest-green.svg)](https://scikit-learn.org/)
[![License](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

A comprehensive collection of Machine Learning algorithms implemented in Python with detailed explanations, visualizations, and practical examples. This repository serves as both a learning resource and a reference for implementing various ML techniques from scratch and using popular libraries.

## 📋 Table of Contents

- [Overview](#-overview)
- [Repository Structure](#-repository-structure)
- [Algorithms Implemented](#-algorithms-implemented)
- [Getting Started](#-getting-started)
- [Installation](#-installation)
- [Usage Examples](#-usage-examples)
- [Datasets Used](#-datasets-used)
- [Contributing](#-contributing)
- [License](#-license)

## 🎯 Overview

This repository contains hands-on implementations of fundamental machine learning algorithms with:

- **Clear Documentation**: Each notebook includes theoretical explanations and practical insights
- **Comprehensive Visualizations**: Plots and graphs to understand algorithm behavior
- **Real-world Datasets**: Applications on popular datasets like breast cancer, spam detection
- **Performance Analysis**: Detailed evaluation metrics and model comparison
- **Best Practices**: Code follows industry standards and includes optimization techniques

## 📁 Repository Structure

```
ML-LAB/
├── 1_L1_L2_Regularization/          # Regularization techniques
│   └── L1_L2_regularization.ipynb
├── 2.Logistic_Regression/           # Logistic regression implementations
│   ├── logistic_regression.ipynb
│   └── Logistic_Regression_breast_cancer.ipynb
├── 3_Naive_Bayes/                   # Naive Bayes classifiers
│   ├── naive_bayes_model.ipynb
│   ├── multinomialNB_breast_cancer.ipynb
│   ├── multinomial_nb_spam.ipynb
│   └── naive-bayes.ipynb
├── 4_Random_Forest/                 # Random Forest algorithms
│   ├── Random_forest_classification.ipynb
│   ├── Random_forest_regression.ipynb
│   └── Random_forest_breast_cancer.ipynb
├── 5_SVM/                          # Support Vector Machines
│   ├── SVM.ipynb
│   └── svm_new.ipynb
├── 6_Clustering/                    # Clustering algorithms
│   ├── k_means_HC_DBScan.ipynb
│   ├── GMM.ipynb
│   ├── GMM_advanced.ipynb
│   ├── DBScan.ipynb
│   └── Hierarchical.ipynb
├── 7_EM_COIN_FLIP/                 # Expectation-Maximization
│   └── EM_coin_flip.ipynb
├── 8_Dimensionality_Reduction/      # Feature reduction techniques
│   ├── pca.ipynb
│   └── pca_breast_cancer.ipynb
├── requirements.txt                 # Python dependencies
├── test_environment.py             # Environment validation script
└── README.md                       # This file
```

## 🧠 Algorithms Implemented

### Supervised Learning
- **Logistic Regression** - Binary and multiclass classification
- **Naive Bayes** - Multinomial and Gaussian variants
- **Random Forest** - Ensemble method for classification and regression
- **Support Vector Machines (SVM)** - Linear and non-linear classification

### Unsupervised Learning
- **K-Means Clustering** - Centroid-based clustering
- **Hierarchical Clustering** - Agglomerative and divisive approaches
- **DBSCAN** - Density-based clustering
- **Gaussian Mixture Models (GMM)** - Probabilistic clustering
- **Principal Component Analysis (PCA)** - Dimensionality reduction

### Statistical Methods
- **Expectation-Maximization (EM)** - Parameter estimation
- **L1/L2 Regularization** - Overfitting prevention techniques

## 🚀 Getting Started

### Prerequisites

- Python 3.8 or higher
- Jupyter Notebook or JupyterLab
- Git (for cloning the repository)

### Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/mdsajjadhossain25/ML-LAB.git
   cd ML-LAB
   ```

2. **Create a virtual environment** (recommended)
   ```bash
   python -m venv env
   source env/bin/activate  # On Windows: env\Scripts\activate
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

4. **Verify installation**
   ```bash
   python test_environment.py
   ```

5. **Launch Jupyter**
   ```bash
   jupyter lab
   ```

## 💡 Usage Examples

### Quick Start with Gaussian Mixture Model

```python
# Example from GMM_advanced.ipynb
from sklearn.mixture import GaussianMixture
from sklearn.datasets import make_blobs
import matplotlib.pyplot as plt

# Generate overlapping clusters
X, y_true = make_blobs(n_samples=300, centers=3, cluster_std=2.5, 
                       center_box=(-5.0, 5.0), random_state=42)

# Apply GMM
gmm = GaussianMixture(n_components=3, random_state=42)
y_pred = gmm.fit_predict(X)

# Visualize results
plt.scatter(X[:, 0], X[:, 1], c=y_pred, cmap='viridis')
plt.title('GMM Clustering Results')
plt.show()
```

### Logistic Regression with Feature Importance

```python
# Example from Logistic_Regression_breast_cancer.ipynb
from sklearn.linear_model import LogisticRegression
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split

# Load data
data = load_breast_cancer()
X_train, X_test, y_train, y_test = train_test_split(
    data.data, data.target, test_size=0.2, random_state=42
)

# Train model
lr = LogisticRegression(random_state=42)
lr.fit(X_train, y_train)

# Evaluate
accuracy = lr.score(X_test, y_test)
print(f"Accuracy: {accuracy:.4f}")
```

## 📊 Datasets Used

- **Breast Cancer Wisconsin Dataset** - Binary classification for cancer diagnosis
- **Spam Detection Dataset** - Text classification for email spam filtering
- **Synthetic Datasets** - Custom generated data for algorithm demonstration
- **Iris Dataset** - Multi-class classification benchmark
- **Wine Dataset** - Classification with multiple features

## 🔍 Key Features

### Comprehensive Analysis
- Performance metrics (Accuracy, Precision, Recall, F1-Score, AUC-ROC)
- Cross-validation and hyperparameter tuning
- Learning curves and validation curves
- Feature importance analysis

### Advanced Visualizations
- Decision boundaries and classification regions
- Clustering uncertainty and probability distributions
- Principal component analysis plots
- Confusion matrices and ROC curves

### Code Quality
- Well-documented and commented code
- Modular and reusable functions
- Error handling and validation
- PEP 8 compliant styling

## 🛠️ Dependencies

```
numpy>=1.21.0
pandas>=1.3.0
matplotlib>=3.4.0
seaborn>=0.11.0
scikit-learn>=1.0.0
statsmodels>=0.12.0
jupyter>=1.0.0
plotly>=5.0.0
mglearn>=0.1.9
```

## 📚 Learning Path

For beginners, we recommend following this sequence:

1. **Start with Supervised Learning**
   - Logistic Regression → Naive Bayes → Random Forest → SVM

2. **Move to Unsupervised Learning**
   - K-Means → Hierarchical Clustering → DBSCAN → GMM

3. **Explore Advanced Topics**
   - PCA → Regularization → EM Algorithm

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request. For major changes:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

### Contribution Guidelines
- Follow existing code style and documentation standards
- Add comprehensive comments and docstrings
- Include visualizations where appropriate
- Test your code before submitting

## 📈 Future Enhancements

- [ ] Deep Learning implementations (Neural Networks, CNNs, RNNs)
- [ ] Time Series Analysis algorithms
- [ ] Natural Language Processing techniques
- [ ] Reinforcement Learning examples
- [ ] MLOps and model deployment examples
- [ ] Interactive dashboards with Streamlit/Dash

## 📞 Contact

**MD Sajjad Hossain**
- GitHub: [@mdsajjadhossain25](https://github.com/mdsajjadhossain25)
- Email: mdsajjadhossain25@example.com

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- Scikit-learn community for excellent documentation
- Jupyter Project for the amazing notebook environment
- All contributors and the open-source community

---

⭐ **Star this repository if you find it helpful!**

*This repository is actively maintained and updated with new algorithms and improvements.*