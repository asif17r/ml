# Machine-Learning-Lab
**Name:** Souvik Sanyal  
**ID:** 2011176108  
**Session:** 2019-20  
**Department:** Computer Science and Engineering  


## 📋 Experiment List
- Lab work01: Classification Algorithm Comparision (Logistic Regression,Support Vector Machine, Naive Bayes, Random Forrest)
- Lab work02: Clustering Algorithm Comparision (K-means Clustering and Gaussinan Mixture Model)
- Lab work03: Dimention Reduction Technique (Principal Component Analysis)
